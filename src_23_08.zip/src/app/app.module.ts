import { NgModule, ErrorHandler } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { IonicApp, IonicModule, IonicErrorHandler } from 'ionic-angular';
import { MyApp } from './app.component';
import { Camera } from '@ionic-native/camera';
import { HttpClientModule } from '@angular/common/http';
import { Geolocation } from '@ionic-native/geolocation';
import { FileChooser } from '@ionic-native/file-chooser';

// Import ionic2-rating module
import { Ionic2RatingModule } from 'ionic2-rating';

import { HomePage } from '../pages/home/home';
import { ListPage } from '../pages/list/list';
import { ClaimPage } from '../pages/claim/claim';
import { PolicyPage } from '../pages/policy/policy';
import { ClaimDetailsPage } from '../pages/claimdetails/claimdetails';
import { ChooseservicePage } from '../pages/chooseservice/chooseservice';
import { ResultPage } from '../pages/result/result';
import { TimelinePage } from '../pages/timeline/timeline';

import { StatusBar } from '@ionic-native/status-bar';
import { SplashScreen } from '@ionic-native/splash-screen';
import { ClaimServiceProvider } from '../providers/claim-service/claim-service';

@NgModule({
  declarations: [
    MyApp,
    HomePage,
    ListPage,
    ClaimPage,
    PolicyPage,
    ClaimDetailsPage,
    ChooseservicePage,
    ResultPage,
    TimelinePage,
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    IonicModule.forRoot(MyApp),
    Ionic2RatingModule,
  ],
  bootstrap: [IonicApp],
  entryComponents: [
    MyApp,
    HomePage,
    ListPage,
    ClaimPage,
    PolicyPage,
    ClaimDetailsPage,
    ChooseservicePage,
    ResultPage,
    TimelinePage,
  ],
  providers: [
    StatusBar,
    SplashScreen,
    Camera,
    {provide: ErrorHandler, useClass: IonicErrorHandler},
    ClaimServiceProvider,
    Geolocation,
    FileChooser,
  ]
})
export class AppModule {}
