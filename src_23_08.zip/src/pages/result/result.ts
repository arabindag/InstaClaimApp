import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, AlertController } from 'ionic-angular';
import { ChooseservicePage } from '../chooseservice/chooseservice';


/**
* Generated class for the ResultPage page.
*
* See https://ionicframework.com/docs/components/#navigation for more info on
* Ionic pages and navigation.
*/


@IonicPage()
@Component({
  selector: 'page-result',
  templateUrl: 'result.html',
})

export class ResultPage {

  totalDamageIndex: number;
  damageToTimelineRatio: number[] = [
    2,
    4,
    10,
    15,
    25
  ];

  damageTimeline: number;
  frontDamage: number=0;
  leftDamage: number=0;
  rightDamage: number=0;
  rearDamage: number=0;
  totalDamage: number=0;

  frontDamageCostRatio: number[] = [
    200,
    600,
    1000,
    12000,
    15000
  ];

  leftDamageCostRatio: number[] = [
    50,
    100,
    180,
    260,
    500
  ];

  rightDamageCostRatio: number[] = [
    50,
    100,
    180,
    260,
    500
  ];

  rearDamageCostRatio: number[] = [
    100,
    250,
    500,
    800,
    1000
  ];

 

  frontDamageCost: number;
  leftDamageCost: number;
  rightDamageCost: number;
  rearDamageCost: number;

  totalDamageCost: number;
data:any;
testdata:any;
damageType:string;
flatCharge:number;
workType:string;
repairTime:number;
labourCost:number;
partsCost:number;
prymaryCost:number;
totalLabourCost:number;
totalCost:number;
allTotalCost:number;
allTotalPartsCost:number;
allTotalLabourCost:number;
damage:any=[{damagePart:"",damagePer:0,damageType:"",workType:"",partsCost:0,prymaryCost:0,repairTime:0,labourCost:0,totalCost:0 }];
  constructor(public navCtrl: NavController, public navParams: NavParams,private alertCtrl: AlertController) {
     this.data = JSON.parse(this.navParams.data);
     this.testdata=this.data.frontimg
    if(this.data.frontimg!=""){this.frontDamage = 20;}
    if(this.data.backimg!=""){this.rearDamage = 40;}
    if(this.data.leftimg!=""){this.leftDamage = 10;}
    if(this.data.rightimg!=""){this.rightDamage = 60;}
    //this.calculateDamage();
    //this.calculateCost();
    //this.calculateTimeline();
this.Calculate();
  }

  calculateTimeline(){
    if(this.totalDamageCost!=0){
    this.totalDamageIndex = ((this.totalDamage/20)<5?Math.floor(this.totalDamage/20):4);
    this.damageTimeline = this.damageToTimelineRatio[this.totalDamageIndex];
    }
    else{
      this.damageTimeline = 0;
    }
  } 

  calculateCost(){
    if(this.data.frontimg!=""){
    this.frontDamageCost = this.frontDamageCostRatio[((this.frontDamage / 20)<5?Math.floor(this.frontDamage / 20):4)];}
    else{ this.frontDamageCost =0;}

    if(this.data.backimg!=""){
    this.leftDamageCost = this.leftDamageCostRatio[((this.leftDamage / 20)<5?Math.floor(this.leftDamage / 20):4)];}
    else{ this.leftDamageCost =0;}

    if(this.data.leftimg!=""){
    this.rightDamageCost = this.rightDamageCostRatio[((this.rightDamage / 20)<5?Math.floor(this.rightDamage / 20):4)];}
    else{ this.rightDamageCost =0;}

    if(this.data.rightimg!=""){
    this.rearDamageCost = this.rearDamageCostRatio[((this.rearDamage / 20)<5?Math.floor(this.rearDamage / 20):4)];}
    else{ this.rearDamageCost =0;}

    this.totalDamageCost = this.frontDamageCost + this.leftDamageCost + this.rightDamageCost + this.rearDamageCost;
  }

 

  calculateDamage(){
    this.totalDamage = (this.frontDamage + this.leftDamage + this.rightDamage + this.rearDamage)/4;
  }

  //-------------------------------------------------------------------------------
  defineTypes(damagePart:string,percentage:number){
if(percentage>0 && percentage<=20){
  this.damageType ="Minor";
  this.workType="Repair";
  this.repairTime = 2;
  this.labourCost = 30;
  this.partsCost = 0;
  this.flatCharge=50;
}
else if(percentage>20 && percentage<=50){
  this.damageType ="Medium";
  this.workType="Repair";
  this.repairTime = 4;
  this.labourCost = 30;
  this.partsCost = 0;
  this.flatCharge=50;
}
else if(percentage>20 && percentage<=50){
  this.damageType ="Major";
  this.workType="Replace";
  this.repairTime = 6;
  this.labourCost = 30;
  this.partsCost = 35;
  this.flatCharge=50;
}
else{
  this.damageType ="No Damage";
  this.workType="Nothing";
  this.repairTime = 0;
  this.labourCost = 0;
  this.partsCost = 0;
  this.flatCharge=0;
}
this.prymaryCost=(this.flatCharge + (this.flatCharge*(this.frontDamage/100)));
this.totalLabourCost=(this.repairTime*this.labourCost);
this.totalCost = (this.partsCost + this.prymaryCost + this.totalLabourCost);
if(this.totalCost!=0){
this.damage.push({damagePart:damagePart,
damegePer:percentage,
damageType:this.damageType,
workType:this.workType,
partsCost:this.partsCost,
prymaryCost:this.prymaryCost,
repairTime:this.repairTime,
labourCost:this.totalLabourCost,
totalCost: this.totalCost});
}
  }

Calculate(){
  this.defineTypes("Front",this.frontDamage);
  this.defineTypes("Back",this.rearDamage);
  this.defineTypes("Left",this.leftDamage);
  this.defineTypes("Right",this.rightDamage);
  this.damage.splice(0, 1);
  this.totalDamageCost=0;
  this.damageTimeline=0;
  this.allTotalPartsCost=0;
  this.allTotalLabourCost=0;
  for(let item of this.damage) {
    this.totalDamageCost = this.totalDamageCost +  item.totalCost;
    this.damageTimeline = this.damageTimeline + item.repairTime;
    this.allTotalPartsCost = this.allTotalPartsCost + item.partsCost;
    this.allTotalLabourCost = this.allTotalLabourCost + item.labourCost;
  }
  console.log(this.totalDamageCost);
}
  //-------------------------------------------------------------------------------
 

  ionViewDidLoad() {
    console.log('ionViewDidLoad ResultPage');
  }
  presentConfirm() {
    let alert = this.alertCtrl.create({
      title: 'Confirm Submission',
      message: 'Do you still want to submit the claim?',
      buttons: [
        {
          text: 'No',
          role: 'cancel',
          handler: () => {
          }
        },
        {
          text: 'Yes',
          handler: () => {
          
          this.XAlert();
          }
        }
      ]
    });
    alert.present();
  }
  XAlert() {
    let alert = this.alertCtrl.create({
      title: "Claim Successfully Saved!!!",
      subTitle: "Your Claim Id is CLM001" ,
      buttons: [{
        text: 'OK',
        handler: () => {
          this.navCtrl.push(ChooseservicePage);
        }
      }]
    });
    alert.present();
  }

  goToRepairTime(){ 
    this.presentConfirm();
  }
}

 

 