import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Camera, CameraOptions } from '@ionic-native/camera';
import { FileChooser } from '@ionic-native/file-chooser';

import { ClaimServiceProvider } from '../../providers/claim-service/claim-service';
import { ClaimDetailsPage } from '../claimdetails/claimdetails';
import { ResultPage } from '../result/result';

/**
 * Generated class for the ClaimPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-claim',
  templateUrl: 'claim.html',
})
export class ClaimPage {
  policyid: any;
  claimdata: any;
  claimForm: FormGroup;
  claim = new Claim();
  base64Image : any;
  defaultimg : string = "../../assets/imgs/logo.png";
  public vehicleOptions: string[] = [
    "2010 Suzuki Baleno",
    "Maruti Suzuki Dzire"
  ];

  public causeOptions: string[] = [
    "Collision",
    "Third Party Liability",
    "Comprehensive"
  ];

  public subCauseOptions: string[] = [
    "Hitting a car",
    "Hitting a pedestrian",
    "Hitting a lamp post",
    "Falling debris"
  ];
  constructor(public navCtrl: NavController, public navParams: NavParams, private claimservice: ClaimServiceProvider, 
    private formBuilder: FormBuilder, private camera: Camera,private fileChooser: FileChooser) {
   this.bindData();
    this.claim.vehicle = this.navParams.get('vehicleName');
    this.claim.iscamera =true;
    this.claim.lossdate = new Date().toISOString();
    
    this.claimForm = this.formBuilder.group({
      vehicle: ['', Validators.required],
      lossdate: ['', Validators.required],
      losscause: ['', Validators.required],
      sublosscause: ['', Validators.required],
      //numberofpeopleinjured: ['']
    });
  };
  
  submitNext(){
    this.claim.vehicle = this.claimForm.controls['vehicle'].value
    this.claim.lossdate = this.claimForm.controls['lossdate'].value
    this.claim.losscause = this.claimForm.controls['losscause'].value
    this.claim.sublosscause = this.claimForm.controls['sublosscause'].value
    //this.claim.numberofpeopleinjured = this.claimForm.controls['numberofpeopleinjured'].value    
     this.claim.leftimg = this.CheckDefault(document.getElementById("leftimg").getAttribute('src')); 
    this.claim.rightimg =this.CheckDefault(document.getElementById("rightimg").getAttribute('src')); 
    this.claim.frontimg =this.CheckDefault(document.getElementById("frontimg").getAttribute('src')); 
    this.claim.backimg =this.CheckDefault(document.getElementById("backimg").getAttribute('src')); 
    
    var claimData = JSON.stringify(this.claim);    
    console.log(claimData);
    //this.navCtrl.push(ClaimDetailsPage,claimData);
    this.navCtrl.push(ResultPage,claimData);
  }
  CheckDefault(img:string){
  if(img!=this.defaultimg)
  {
return img;
  }
  else {
return "";
  }
  }
  bindData(){
    this.policyid = this.navParams.get('policyid');
    this.claimdata = {"imagepath":[this.defaultimg,this.defaultimg,this.defaultimg,this.defaultimg],"_id":"5b6f928d3d5c3b90ee479783","policyid":"P001","claimid":"C001","model":"2010 Suzuki Baleno","lossdate":"2018-08-12T01:51:09.759Z","losscause":"Collision","sublosscause":"Hitting a car","iscamera":true};
    this.claimservice.getDetailsByPolicyId("5b6f8ee753a8e609fe43d558").then(data=>{
      console.log("getDetailsByPolicyId");
      console.log( data);
    });
  } 


  openCameraOrFileChooser(ctrl:string,iscamera:boolean){
if(iscamera){
  this.openCamera(ctrl);
}
else{
  this.openFileChooser(ctrl);
}
}
  
   openFileChooser(ctrl:string){
    this.fileChooser.open()
    .then(uri => function(){
      this.base64Image = uri;
     let cameraImageSelector = document.getElementById(ctrl);
     cameraImageSelector.setAttribute('src', this.base64Image);
    }
  )
    .catch(e => console.log(e));
   }
 
  openCamera(ctrl:string){
    const options: CameraOptions = {
      quality: 80,
      destinationType: this.camera.DestinationType.DATA_URL,
      encodingType: this.camera.EncodingType.JPEG,
      mediaType: this.camera.MediaType.PICTURE,
      cameraDirection: this.camera.Direction.BACK,
      saveToPhotoAlbum: true,
    }
    
    this.camera.getPicture(options).then((imageData) => {
     this.base64Image = 'data:image/jpeg;base64,' + imageData;
     let cameraImageSelector = document.getElementById(ctrl);
     cameraImageSelector.setAttribute('src', this.base64Image);
    }, (err) => {
      console.log(err);
    });
  }
}
export class Claim {
  vehicle: string;
  lossdate: String;
  losscause: String;
  sublosscause: String;
  iscamera:boolean;
  leftimg: String;
  rightimg: String;
  frontimg: String;
  backimg: String;
}
