import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { ChooseservicePage } from './chooseservice';

@NgModule({
  declarations: [
    ChooseservicePage,
  ],
  imports: [
    IonicPageModule.forChild(ChooseservicePage),
  ],
})
export class ChooseservicePageModule {}
