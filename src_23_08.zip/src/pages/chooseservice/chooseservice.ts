import { Component, ViewChild, ElementRef } from '@angular/core';
import { IonicPage, NavController, NavParams, Platform, AlertController   } from 'ionic-angular';
import { Geolocation } from '@ionic-native/geolocation';

/**
 * Generated class for the ChooseservicePage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-chooseservice',
  templateUrl: 'chooseservice.html',
})
export class ChooseservicePage {
  rate:any;
  testvar : string;
  public google: any;

  @ViewChild('map') mapElement: ElementRef;
  map: any;
  public workShopJson: any = [
    {"latitude":"22.497107","longitude":"88.515900","address":"2050 Bamako Place, Washington, DC 20521-2050, Mob. No.1234567890","shopname":"A Cars Ltd","rate":"4.0"},
    {"latitude":"22.497101","longitude":"88.515901","address":"7100 Athens Place, Washington, DC 20521-7100, Mob. No.1234567890","shopname":"B Cars Ltd","rate":"3.0"},
    {"latitude":"22.497102","longitude":"88.515902","address":"8400 London Place, Washington, DC 20521-8400, Mob. No.1234567890","shopname":"C Cars Ltd","rate":"2.5"},
    {"latitude":"22.497103","longitude":"88.515903","address":"5520 Quebec Place, Washington, DC 20521-5520, Mob. No.1234567890","shopname":"D Cars Ltd","rate":"1.0"},
    {"latitude":"22.497104","longitude":"88.515904","address":"2430 Nouakchott Place, Washington, DC 20521-2430, Mob. No.1234567890","shopname":"E Cars Ltd","rate":"1.0"}
  ];
  public markers = [];
  constructor(public navCtrl: NavController, public navParams: NavParams, public platform: Platform, 
    private geolocation: Geolocation, private alertCtrl: AlertController) {
    platform.ready().then(() => {
      //this.initMap();
    });
    this.rate=3;
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad ChooseservicePage');
  }
  presentAlert(item:any) {
    let alert = this.alertCtrl.create({
      title: item.shopname,
      subTitle: item.address ,
      buttons: ['Ok']
    });
    alert.present();
  }
  
  XAlert() {
    let alert = this.alertCtrl.create({
      title: "Saved",
      subTitle: "Claim Successfully Saved!!!" ,
      buttons: ['Ok']
    });
    alert.present();
  }
  
  initMap() {
    this.geolocation.getCurrentPosition({ maximumAge: 3000, timeout: 5000, enableHighAccuracy: true }).then((resp) => {
      
      //let mylocation = new google.maps.LatLng(resp.coords.latitude,resp.coords.longitude);
      // this.map = new google.maps.Map(this.mapElement.nativeElement, {
      //   zoom: 15,
      //   center: mylocation
      // });

      this.testvar="getCurrentPosition => latitude: " + resp.coords.latitude + ", longitude: " + resp.coords.longitude;
    });
    let watch = this.geolocation.watchPosition();
    watch.subscribe((data) => {
      // this.deleteMarkers();
      // let updatelocation = new google.maps.LatLng(data.coords.latitude,data.coords.longitude);
      // let image = 'assets/imgs/blue-bike.png';
      // this.addMarker(updatelocation,image);
      // this.setMapOnAll(this.map);
      this.testvar="watchPosition => latitude: " + data.coords.latitude + ", longitude: " + data.coords.longitude;
    });
  }
  // addMarker(location, image) {
  //   let marker = new google.maps.Marker({
  //     position: location,
  //     map: this.map,
  //     icon: image
  //   });
  //   this.markers.push(marker);
  // }  
  // setMapOnAll(map) {
  //   for (var i = 0; i < this.markers.length; i++) {
  //     this.markers[i].setMap(map);
  //   }
  // }  
  // clearMarkers() {
  //   this.setMapOnAll(null);
  // }    
  // deleteMarkers() {
  //   this.clearMarkers();
  //   this.markers = [];
  // }
}

