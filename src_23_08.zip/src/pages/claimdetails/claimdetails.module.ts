import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
//import { ClaiDetailsPage } from './claimdetails';

@NgModule({
  declarations: [
    //ClaimDetailsPage,
  ],
  imports: [
    //IonicPageModule.forChild(ClaimDetailsPage),
  ],
})
export class ClaimdetailsPageModule {}
